
import java.util.Scanner;


public class CHAP_2_PROJECT_03 {
    
    public static void main(String[] args){
    
        double num1;
        double num2;
        double num3;
        
        double reminder ;
        double qoutient;
                
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter First Number ");
        num1 = input.nextDouble();
        
       System.out.println("Enter Second Number ");
        num2 = input.nextDouble();
        
        qoutient = num1/num2;
        reminder = num1%num2;
        
        System.out.printf("Dividend is %.2f\n",num1);
        System.out.printf("Divisor is %.2f\n",num2);
        System.out.printf("Qoutient is %.2f\n",qoutient);
        System.out.printf("Reminder is %.2f\n",reminder);
    }
    
    
}
