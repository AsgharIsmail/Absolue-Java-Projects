import java.util.Scanner;
public class CHAP_2_PROJECT_07 {

    public static void main(String[] args){
        Scanner keyboard = new Scanner(System.in);
      int amount;
      int exchange;
      int dime;
      int quarter;
      int nickels;
      
      System.out.println("Welcome to vendor machine");
      System.out.println("Enter Price of Item");
      System.out.println("(from 25 cents to a dollar, in 5-cent increments): ");
      
      amount = keyboard.nextInt();
      
      exchange = 100 - amount;  // As one dollar is eqaul to 100 cents
        
      quarter = exchange/25;     // one qaurter is equal to 25 cents
      exchange = exchange%25;
      
      dime = exchange/10;        //one dime is equal to 10 cents
      exchange = exchange%10;
      
      nickels = exchange/5;       // one nickel is equal to 5 cents
              
      System.out.println("You bought an item for "+ amount +" cents and gave me a dollar,");
      System.out.println("So your change is");
      System.out.println(quarter + " quarters ,");
      System.out.println(dime + " dimes and ");
      System.out.println(nickels + " nickels ");   
    
    }
    
}
