
import java.util.Scanner;


public class CHAP_2_PROJECT_04 {
    
    public static void main(String[] args){
    
        double distance ;
        double time;
        double speed;
        double hours;
        double minute;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter Distance in miles ");
        distance = input.nextDouble();
        
         System.out.println("Enter Speed in miles per hour");
         speed = input.nextDouble();
         
         time = distance/speed;
         
        hours = time;
        
       minute = (time%3600)/60;
       
       System.out.printf("Time taken will be %.2f hours and %.2f minutes",hours,minute );
        
      
       
        
    
    
    }
}
