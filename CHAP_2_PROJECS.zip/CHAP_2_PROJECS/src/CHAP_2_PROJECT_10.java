
import java.util.Scanner;


public class CHAP_2_PROJECT_10 {
    
   
    
    public static void main(String[] args){
         
    String item_1,item_2,item_3;
    int quantity_1,quantity_2,quantity_3;
    double price_1,price_2,price_3;
    
    Scanner input = new Scanner(System.in);
    
    System.out.println("Input Name of Item 1 :");
    item_1 = input.next();
    System.out.println("Input Quantity of Item 1 :");
    quantity_1 = input.nextInt();
    System.out.println("Input Price if Item 1 :");
    price_1 = input.nextDouble();
    double total_1,total_2,total_3,sub_total;
    
    
     System.out.println("Input Name of Item 2 :");
    item_2 = input.next();
    System.out.println("Input Quantity of Item 2 :");
    quantity_2 = input.nextInt();
    System.out.println("Input Price if Item 2 :");
    price_2 = input.nextDouble();
    
    
     System.out.println("Input Name of Item 3:");
    item_3 = input.next();
    System.out.println("Input Quantity of Item 3 :");
    quantity_3 = input.nextInt();
    System.out.println("Input Price if Item 3 :");
    price_3 = input.nextDouble();
    
    total_1 = quantity_1 * price_1;
    total_2 = quantity_2 * price_2;
    total_3 = quantity_3 * price_3;
    
    sub_total = total_1 + total_2 + total_3;
    
    double tax = (sub_total*6.25)/100;
    double total =  sub_total + tax;
    
     System.out.println("Your Bill");
    
     System.out.printf("%-20s %-10s %-10s  %-10s\n","Item","Price","Quantity","Total");
     System.out.printf("%-20s %-10.2f %-10d  %5.2f\n",item_1,price_1,quantity_1,total_1);
     System.out.printf("%-20s %-10.2f %-10d  %5.2f\n",item_2,price_2,quantity_2,total_2);
     System.out.printf("%-20s %-10.2f %-10d  %-10.2f\n",item_3,price_3,quantity_3,total_3);
     System.out.printf("%-20s %-10s %-10s  %-10.2f\n","Sub Total","       ","      ",sub_total);
     System.out.printf("%-20s %-10s %-10s  %-10.2f\n","6.25% SalesTax ","       ","      ",tax);
     System.out.printf("%-20s %-10s %-10s  %-10.2f\n","Total","       ","      ",total);
     
     
      
     
    
}
}
