
import java.util.Scanner;


public class CHAP_2_PROJECT_14 {

public static void main(String[] args){
    
    String drink_name;
    int amount_of_caffine;
    int size_of_drink;
    int lethal_caffine = 10000;
    
    
    Scanner input = new Scanner(System.in);
    
   System.out.println("Enter name of drink "); 
   drink_name = input.next();
   System.out.println("Enter Size of Drink in ounce ");
   size_of_drink = input.nextInt();
   System.out.println("Enter Amount of Caffine in mg ");
   amount_of_caffine = input.nextInt();
     
   int no_of_drinks = (lethal_caffine/amount_of_caffine)/size_of_drink; 
           
    System.out.println(no_of_drinks +" drinks of "+ drink_name +" each " +size_of_drink + "ounce are LETHAL if drink once");
    



}
    
}
