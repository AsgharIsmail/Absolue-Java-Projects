
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class CHAP_2_PROJECT_14_PAR_2 {
    
    public static void main(String[] args){
   
 Scanner infile = null;
       try{
        
     infile = new Scanner(new FileInputStream("drink.txt"));   
    }catch(FileNotFoundException e){
     System.out.println("File not Found");
     
     System.exit(0);
    }
    
   
   
   String drink_name;
    int amount_of_caffine;
    int size_of_drink;
    int lethal_caffine = 10000;
    
   //System.out.println(" Text left to read in file ?" + infile.hasNextLine());
    
   drink_name = infile.nextLine();
   size_of_drink = infile.nextInt();
   amount_of_caffine = infile.nextInt();
   
   int no_of_drinks = (lethal_caffine/amount_of_caffine)/size_of_drink; 
           
    System.out.println(no_of_drinks +" drinks of "+ drink_name +" each " +size_of_drink + "ounce are LETHAL if drink once");
    
    infile.close();
}
}