import java.util.Scanner;
import java.text.DecimalFormat;

public class CHAP_2_PROJECT_11 {
        
    public static void main(String[] args){
         
    String exercise_1,exercise_2,exercise_3;
    int score_1,score_2,score_3;
    int possible_score_1,possible_score_2,possible_score_3;
    double total_1,total_2;
    
    DecimalFormat percent = new DecimalFormat("##.00%");
    
    Scanner input = new Scanner(System.in);
    
    System.out.println("Name of exercise 1  :");
    exercise_1 = input.nextLine();
    System.out.println("Score received for exercise 1: :");
    score_1 = input.nextInt();
    System.out.println("Total points possible for exercise 1 :");
    possible_score_1 = input.nextInt();
    String junk = input.nextLine();
    
    System.out.println("Name of exercise 2  :");
    exercise_2 = input.nextLine();
    System.out.println("Score received for exercise 2 :");
    score_2 = input.nextInt();
    System.out.println("Total points possible for exercise 2 :");
    possible_score_2 = input.nextInt();
     String junk2 = input.nextLine();
    
    System.out.println("Name of exercise 3  :");
    exercise_3 = input.nextLine();
    System.out.println("Score received for exercise 3 :");
    score_3 = input.nextInt();
    System.out.println("Total points possible for exercise 3 :");
    possible_score_3 = input.nextInt();
     String junk3 = input.nextLine();
    
    
    total_1 = score_1 + score_2 + score_3;
    total_2 =  possible_score_1 +  possible_score_2 + possible_score_3;
    
  
     System.out.println("   Score Table");
    
     System.out.printf("%-20s %-10s %-10s\n","Exercise","Score","Possible Score" );
     System.out.printf("%-20s %-10d %-10d\n",exercise_1,score_1,possible_score_1);
     System.out.printf("%-20s %-10d %-10d\n",exercise_2,score_2,possible_score_2);
     System.out.printf("%-20s %-10d %-10d\n",exercise_3,score_3,possible_score_3);
     System.out.printf("%-20s %-10.2f %-10.2f\n","Total",total_1,total_2);
     System.out.println("Your Total Score is " +total_1 + " out of "+ total_2 +" or "+ percent.format((double)total_1/total_2)+".");
     
     
      
     
    
}
}
    

