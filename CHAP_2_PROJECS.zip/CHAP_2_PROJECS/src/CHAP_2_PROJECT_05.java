
import java.util.Scanner;
public class CHAP_2_PROJECT_05 {
    public static void main(String[] args){
        
       double percentage ;
       double gpa;
       
       Scanner input = new Scanner(System.in);
       System.out.println("Enter your percentage ");
       percentage = input.nextDouble();
       
       gpa = (percentage/100)*4;
       
       System.out.printf("GPA according to given percentage is %.2f\n",gpa);
    }
}
