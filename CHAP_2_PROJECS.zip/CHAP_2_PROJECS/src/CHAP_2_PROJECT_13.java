import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class CHAP_2_PROJECT_13 {
    
     public static void main(String[] args){
    
Scanner myfile = null;

try{

    myfile = new Scanner(new FileInputStream("file.txt"));
    
}catch(FileNotFoundException e){

System.out.println("File not found");
System.exit(0); }

        
    int ideal_weight = 110;
    int minimum_height = 5;
    int weight_per_additional_inch_in_height = 5;
    int inch_per_feet = 12;

    String person_name;
    double ideal_weight_person ;
    double additional_weight;
    double additional_height_inch;
     int person_height_feet;
     int person_height_inch;
     
    person_name = myfile.nextLine();
    person_height_feet = myfile.nextInt();
    person_height_inch = myfile.nextInt();
    
    
    
     additional_height_inch = inch_per_feet*(person_height_feet - minimum_height) + person_height_inch ;
     
             
    additional_weight = additional_height_inch* weight_per_additional_inch_in_height;
    
    ideal_weight_person = ideal_weight + additional_weight;
    
    
    
    System.out.println("Person Name : "+  person_name + "  Ideal Body Weight in pounds: " +  ideal_weight_person);    
    }
}
