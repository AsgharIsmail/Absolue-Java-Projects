import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class CHAP_2_PROJECT_12 {
public static void main(String[] args){
    
    Scanner file =null;
    
    try{
    
        file = new Scanner(new FileInputStream("myfile.txt"));
    }catch(FileNotFoundException e){
    
   System.out.println("File not Found");
   System.exit(0);
   }
String input_string;

input_string = file.nextLine();

String replaced_string;

replaced_string = input_string.replaceFirst("hate" , "love");

System.out.println("Input String is ");
System.out.println(input_string);
System.out.println("Replaced Input String is ");
System.out.println(replaced_string);
 
file.close();

}
    }
