
import java.util.Scanner;


public class CHAP_2_PROJECT_01 {
    
    
    public static void main(String[] args){
    
       Scanner input = new Scanner(System.in);
       
       double n;
       double r;
       double guess;
       
       System.out.println("Enter Value for Sqaureroot");
       n = input.nextDouble();
       
       guess = n/2;
       
       r = n/guess;                     //REAPEAT IT FIVE TIMES ACCORDING TO ALGORITHM 
       guess = (guess + r)/2.00;
       
       r = n/guess;
       guess = (guess + r)/2.00;
       
       r = n/guess;
       guess = (guess + r)/2.00;
       
       r = n/guess;
       guess = (guess + r)/2.00;
       
       r = n/guess;
       guess = (guess + r)/2.00;
       
         System.out.printf("The square root of %.2f is approximately: %.2f\n", n, guess);
             
    
    
    }
}
