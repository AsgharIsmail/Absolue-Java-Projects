
import java.util.Scanner;
public class CHAP_2_PROJECT_09 {
    
    public static void main(String[] args){
    
String input_line;

String replaced_line;
        
    Scanner keyboard = new Scanner(System.in);
   
    System.out.println("Enter Line of Text ");
    input_line = keyboard.nextLine();
    
replaced_line = input_line.replaceFirst("hate" , "love");

System.out.println("I have rephrased that line to read ");
System.out.println(replaced_line);
 


}
}
