
import java.util.Scanner;


public class CHAP_2_PROJECT_08 {
 
    public static void main(String[] args){
    
        String word1,word2 ,word3;
       
        
        Scanner input = new Scanner(System.in);
        
        
        
        System.out.println("Enter three words separated by spaces ");
        
        
        
        word1 = input.next();
        word2 = input.next();
        word3 = input.next();
         
        System.out.println("Three words in one line will be " + word1 + " " + word2  + " " + word3);
        
        System.out.println("Three words sperated diffrent line ");
        
        System.out.println(word1);
         System.out.println(word2);
          System.out.println(word3);
    
    
    
    
    }
}
