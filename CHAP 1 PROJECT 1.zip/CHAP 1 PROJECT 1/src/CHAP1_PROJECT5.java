 
public class CHAP1_PROJECT5 {
    
    public static final String string_changed = "I hate Programming";
    
    public static void main(String[] args){
    
    
    
    }
    
    
}
