
public class CHAP_1_PROJECT_9 {
    
    public static void main(String[] args){
    
        
    int ideal_weight = 110;
    int minimum_height = 5;
    int weight_per_additional_inch_in_height = 5;
    int inch_per_feet = 12;
    
    double ideal_weight_person;
    double additional_weight;
    double additional_height_inch;
    int person_height_feet = 6;
    int person_height_inch = 3;
    
    
    
     additional_height_inch = inch_per_feet*(person_height_feet - minimum_height) + person_height_inch ;
     
             
    additional_weight = additional_height_inch* weight_per_additional_inch_in_height;
    
    ideal_weight_person = ideal_weight + additional_weight;
    
    
    System.out.println("Person height in feet: " + person_height_feet + "." + person_height_inch);
    System.out.println("Ideal Body Weight in pounds: " +  ideal_weight_person);    
    }
}
