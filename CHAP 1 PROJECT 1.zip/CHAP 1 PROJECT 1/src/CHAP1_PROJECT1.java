public class CHAP1_PROJECT1 {
  
  public static void main(String args[]){
  
  double weight_kilogram= 65;
  double height_meters= 5.9;
  double BMI;
  
 
  BMI = (weight_kilogram/(height_meters*height_meters));
  
  System.out.println("Weight in KG = " + weight_kilogram + " Kg");
  System.out.println("Height in meters = " + height_meters + " m");
  System.out.println(" BMI is " + BMI);
  }
}
