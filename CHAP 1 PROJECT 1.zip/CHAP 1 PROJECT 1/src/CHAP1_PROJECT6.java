
public class CHAP1_PROJECT6 {
    
    public static int initial_principal_amount = 1000;
    public static int initial_interest_rate = 5;
    public static int no_of_years = 5;
    
    public static double simple_interest;
     
    public static void main(String[] args){
    
    simple_interest = ( initial_principal_amount*initial_interest_rate*no_of_years)/100;
    
    System.out.println("Initial Principal Amount = $" + initial_principal_amount);
    System.out.println("Initial Interest Rate = " + initial_interest_rate + "%");
    System.out.println("No. of Years = " + no_of_years);
    System.out.println("Simple Interst will be  = " + simple_interest);
    
}
}