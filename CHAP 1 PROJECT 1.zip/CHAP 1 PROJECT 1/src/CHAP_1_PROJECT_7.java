
public class CHAP_1_PROJECT_7 {
    
    
    
  public static void main (String[] args){
  
  int total_seconds = 50391;
    
    int hours;
    int minutes;
    int seconds;
    int remaining_seconds;
    
    hours = total_seconds/3600;       //total seconds per hour is 3600
    
    remaining_seconds = total_seconds % 3600;
    
    minutes = remaining_seconds / 60;
    
    remaining_seconds = remaining_seconds % 60;
    
    seconds = remaining_seconds;
    
   System.out.println("There are " + hours + " hours, " + minutes + " minutes, and " + seconds + " seconds in " + total_seconds + " seconds");
    
    
  
  }
}
