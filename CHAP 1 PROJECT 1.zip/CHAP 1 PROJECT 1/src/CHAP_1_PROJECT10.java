
public class CHAP_1_PROJECT10 {
    
    public static void main(String[] args){
        
         int lethal_caffine = 10000;
        int cocacola_caffine = 34;
        int coffee_caffine = 160;
        
       int lethal_cocacola_caffine = lethal_caffine/cocacola_caffine ;
       
       int lethal_coffee_caffine = lethal_caffine/coffee_caffine;
               
     int  no_of_cocacola_cans = lethal_cocacola_caffine/12;   // A 12 OUNCE COCACOLA CAN HAS 34mg OF CAFFINE 
     int  no_of_coffee_cups = lethal_coffee_caffine/16 ;      // A 16 OUNCE COFFEE CUP HAS 160mg OF COFFEE     
     
    System.out.println("A 12 OUNCE COCACOLA CAN HAS 34mg OF CAFFINE ");
    System.out.println(no_of_cocacola_cans + " CANS ARE LETHAL IF DRINK ONCE ");
    System.out.println("A 16 OUNCE COFFEE CUP HAS 160mg OF COFFEE" );
    System.out.println(no_of_coffee_cups + " CUPS ARE LETHAL IF DRINK ONCE ");
    }
    
    
}
